#ifndef TcpSocketVaxRoutines_h
#define TcpSocketVaxRoutines_h

#include <stdlib.h>
#include <socket.h>

int tcpSocketVaxAccept(int s, sockaddr*, size_t*);
int tcpSocketVaxRecv(int s, void* buf, size_t length, int);
int tcpSocketVaxSend(int s, void const* buf, size_t length, int);

#endif
