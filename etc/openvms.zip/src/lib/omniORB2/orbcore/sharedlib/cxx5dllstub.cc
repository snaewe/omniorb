// -*- Mode: C++; -*-
//                            Package   : omniORB2
// cxx5dllstub.cc             Created on: 2000-05-17
//                            Author    : Bruce Visscher (bcv)
//
//  Adapted from msvcstub.cc
//
//    Copyright (C) 1996-2000 AT&T Laboratories Cambridge
//
//    This file is part of the omniORB library
//
//    The omniORB library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Library General Public
//    License as published by the Free Software Foundation; either
//    version 2 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Library General Public License for more details.
//
//    You should have received a copy of the GNU Library General Public
//    License along with this library; if not, write to the Free
//    Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  
//    02111-1307, USA
//
//
// Description:
//
//	The only purpose of this file is to make it possible to link the
//	orbcore shareable image using Compaq C+5.6. None of these functions
//	are used in the DLL.
//
//	I don't know why they are required.  Note that this is similar to the
//	MSVC problemm but more severe.

#define ENABLE_CLIENT_IR_SUPPORT
#include <omniORB3/CORBA.h>

//  Destructors

CORBA::_pof_FixedDef::~_pof_FixedDef() {}
CORBA::_pof_IRObject::~_pof_IRObject() {}
CORBA::_pof_ArrayDef::~_pof_ArrayDef() {}
CORBA::ExceptionList::~ExceptionList() {}
CORBA::ServerRequest::~ServerRequest() {}
CORBA::_pof_Contained::~_pof_Contained() {}
CORBA::_pof_Container::~_pof_Container() {}
CORBA::_pof_StringDef::~_pof_StringDef() {}
CORBA::_objref_IDLType::~_objref_IDLType() {}
CORBA::_pof_Repository::~_pof_Repository() {}
CORBA::_pof_WstringDef::~_pof_WstringDef() {}
CORBA::TypeCode_member::~TypeCode_member() {}
CORBA::_objref_FixedDef::~_objref_FixedDef() {}
CORBA::_objref_IRObject::~_objref_IRObject() {}
CORBA::_objref_ArrayDef::~_objref_ArrayDef() {}
CORBA::_pof_SequenceDef::~_pof_SequenceDef() {}
CORBA::WrongTransaction::~WrongTransaction() {}
CORBA::_objref_Contained::~_objref_Contained() {}
CORBA::_objref_Container::~_objref_Container() {}
CORBA::_objref_StringDef::~_objref_StringDef() {}
CORBA::_pof_InterfaceDef::~_pof_InterfaceDef() {}
CORBA::_pof_PrimitiveDef::~_pof_PrimitiveDef() {}
CORBA::_pof_OperationDef::~_pof_OperationDef() {}
CORBA::_objref_Repository::~_objref_Repository() {}
CORBA::_objref_WstringDef::~_objref_WstringDef() {}
CORBA::_objref_SequenceDef::~_objref_SequenceDef() {}
CORBA::_objref_InterfaceDef::~_objref_InterfaceDef() {}
CORBA::_objref_PrimitiveDef::~_objref_PrimitiveDef() {}
CORBA::_objref_OperationDef::~_objref_OperationDef() {}
CORBA::UnknownUserException::~UnknownUserException() {}
CORBA::ContextList::Bounds::~Bounds() {}
CORBA::ExceptionList::Bounds::~Bounds() {}
CORBA::ORB::InconsistentTypeCode::~InconsistentTypeCode() {}
CORBA::DynAny::InvalidSeq::~InvalidSeq() {}
CORBA::DynAny::InvalidValue::~InvalidValue() {}
CORBA::DynAny::TypeMismatch::~TypeMismatch() {}
CORBA::DynAny::Invalid::~Invalid() {}
CORBA::TypeCode::Bounds::~Bounds() {}
CORBA::TypeCode::BadKind::~BadKind() {}
CORBA::NamedValue::~NamedValue() {}
CORBA::ContextList::~ContextList() {}
CORBA::DynSequence::~DynSequence() {}
CORBA::_pof_IDLType::~_pof_IDLType() {}
CORBA::Any::~Any() {}
CORBA::NVList::~NVList() {}
CORBA::Context::~Context() {}
CORBA::DynEnum::~DynEnum() {}
CORBA::Request::~Request() {}
CORBA::DynArray::~DynArray() {}
CORBA::DynUnion::~DynUnion() {}
CORBA::TypeCode::~TypeCode() {}
CORBA::DynStruct::~DynStruct() {}
CORBA::NVList::Bounds::~Bounds() {}
CORBA::DynAny::~DynAny() {}

//  void functions

void CORBA::WrongTransaction::_NP_marshal(MemBufferedStream &) const {}
void CORBA::WrongTransaction::_NP_marshal(NetBufferedStream &) const {}
void CORBA::UnknownUserException::_NP_marshal(NetBufferedStream &) const {}
void CORBA::UnknownUserException::_NP_marshal(MemBufferedStream &) const {}
void CORBA::ContextList::Bounds::_NP_marshal(MemBufferedStream &) const {}
void CORBA::ContextList::Bounds::_NP_marshal(NetBufferedStream &) const {}
void CORBA::ExceptionList::Bounds::_NP_marshal(MemBufferedStream &) const {}
void CORBA::ExceptionList::Bounds::_NP_marshal(NetBufferedStream &) const {}
void CORBA::ORB::InconsistentTypeCode::_NP_marshal(NetBufferedStream &) const {}
void CORBA::ORB::InconsistentTypeCode::_NP_marshal(MemBufferedStream &) const {}
void CORBA::DynAny::InvalidValue::_NP_marshal(MemBufferedStream &) const {}
void CORBA::DynAny::TypeMismatch::_NP_marshal(MemBufferedStream &) const {}
void CORBA::DynAny::InvalidSeq::_NP_marshal(MemBufferedStream &) const {}
void CORBA::DynAny::TypeMismatch::_NP_marshal(NetBufferedStream &) const {}
void CORBA::DynAny::InvalidSeq::_NP_marshal(NetBufferedStream &) const {}
void CORBA::DynAny::InvalidValue::_NP_marshal(NetBufferedStream &) const {}
void CORBA::DynAny::Invalid::_NP_marshal(NetBufferedStream &) const {}
void CORBA::DynAny::Invalid::_NP_marshal(MemBufferedStream &) const {}
void CORBA::NVList::Bounds::_NP_marshal(MemBufferedStream &) const {}
void CORBA::NVList::Bounds::_NP_marshal(NetBufferedStream &) const {}
void CORBA::TypeCode::Bounds::_NP_marshal(MemBufferedStream &) const {}
void CORBA::TypeCode::Bounds::_NP_marshal(NetBufferedStream &) const {}
void CORBA::TypeCode::BadKind::_NP_marshal(NetBufferedStream &) const {}
void CORBA::TypeCode::BadKind::_NP_marshal(MemBufferedStream &) const {}
void CORBA::WrongTransaction::_raise() {}
void CORBA::UnknownUserException::_raise() {}
void CORBA::ContextList::Bounds::_raise() {}
void CORBA::ExceptionList::Bounds::_raise() {}
void CORBA::ORB::InconsistentTypeCode::_raise() {}
void CORBA::DynAny::InvalidSeq::_raise() {}
void CORBA::DynAny::InvalidValue::_raise() {}
void CORBA::DynAny::TypeMismatch::_raise() {}
void CORBA::DynAny::Invalid::_raise() {}
void CORBA::NVList::Bounds::_raise() {}
void CORBA::TypeCode::Bounds::_raise() {}
void CORBA::TypeCode::BadKind::_raise() {}
void CORBA::IDLType_Helper::release(CORBA::_objref_IDLType*) {}
void CORBA::Contained_Helper::release(CORBA::_objref_Contained*) {}

//  Non-void functions:

unsigned char CORBA::_pof_IDLType::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_FixedDef::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_IRObject::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_ArrayDef::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_Contained::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_Container::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_StringDef::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_Repository::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_WstringDef::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_SequenceDef::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_InterfaceDef::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_PrimitiveDef::is_a(const char*) const{return 0;}
unsigned char CORBA::_pof_OperationDef::is_a(const char*) const{return 0;}
unsigned char CORBA::Contained_Helper::is_nil(CORBA::_objref_Contained*){return 0;}
CORBA::Exception* CORBA::WrongTransaction::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::UnknownUserException::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::ContextList::Bounds::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::ExceptionList::Bounds::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::ORB::InconsistentTypeCode::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::DynAny::InvalidSeq::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::DynAny::InvalidValue::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::DynAny::TypeMismatch::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::DynAny::Invalid::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::NVList::Bounds::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::TypeCode::Bounds::_NP_duplicate() const{return 0;}
CORBA::Exception* CORBA::TypeCode::BadKind::_NP_duplicate() const{return 0;}
const char* CORBA::WrongTransaction::_NP_repoId(int*) const{return 0;}
const char* CORBA::UnknownUserException::_NP_repoId(int*) const{return 0;}
const char* CORBA::ContextList::Bounds::_NP_repoId(int*) const{return 0;}
const char* CORBA::ExceptionList::Bounds::_NP_repoId(int*) const{return 0;}
const char* CORBA::ORB::InconsistentTypeCode::_NP_repoId(int*) const{return 0;}
const char* CORBA::DynAny::InvalidValue::_NP_repoId(int*) const{return 0;}
const char* CORBA::DynAny::TypeMismatch::_NP_repoId(int*) const{return 0;}
const char* CORBA::DynAny::InvalidSeq::_NP_repoId(int*) const{return 0;}
const char* CORBA::DynAny::Invalid::_NP_repoId(int*) const{return 0;}
const char* CORBA::NVList::Bounds::_NP_repoId(int*) const{return 0;}
const char* CORBA::TypeCode::Bounds::_NP_repoId(int*) const{return 0;}
const char* CORBA::TypeCode::BadKind::_NP_repoId(int*) const{return 0;}
unsigned char CORBA::TypeCode::NP_is_nil() const{return 0;}
const char* CORBA::WrongTransaction::_NP_typeId() const{return 0;}
const char* CORBA::UnknownUserException::_NP_typeId() const{return 0;}
const char* CORBA::ContextList::Bounds::_NP_typeId() const{return 0;}
const char* CORBA::ExceptionList::Bounds::_NP_typeId() const{return 0;}
const char* CORBA::ORB::InconsistentTypeCode::_NP_typeId() const{return 0;}
const char* CORBA::DynAny::Invalid::_NP_typeId() const{return 0;}
const char* CORBA::DynAny::InvalidValue::_NP_typeId() const{return 0;}
const char* CORBA::DynAny::TypeMismatch::_NP_typeId() const{return 0;}
const char* CORBA::DynAny::InvalidSeq::_NP_typeId() const{return 0;}
const char* CORBA::NVList::Bounds::_NP_typeId() const{return 0;}
const char* CORBA::TypeCode::BadKind::_NP_typeId() const{return 0;}
const char* CORBA::TypeCode::Bounds::_NP_typeId() const{return 0;}
omniObjRef* CORBA::_pof_IDLType::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_FixedDef::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_IRObject::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_ArrayDef::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_Container::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_Contained::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_StringDef::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_Repository::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_WstringDef::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_SequenceDef::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_InterfaceDef::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_PrimitiveDef::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
omniObjRef* CORBA::_pof_OperationDef::newObjRef(const char*, _CORBA_Unbounded_Sequence<IOP::TaggedProfile >*, omniIdentity*, omniLocalIdentity*){return 0;}
void* CORBA::_objref_IDLType::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_ArrayDef::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_IRObject::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_FixedDef::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_StringDef::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_Contained::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_Container::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_WstringDef::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_Repository::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_SequenceDef::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_InterfaceDef::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_OperationDef::_ptrToObjRef(const char*){return 0;}
void* CORBA::_objref_PrimitiveDef::_ptrToObjRef(const char*){return 0;}
