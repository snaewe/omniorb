import sys

expected=5
if len(sys.argv) != expected+1:
    raise Exception(
	'''Wrong number of arguments: %d, expected: %d'''
	% (len(sys.argv)-1, expected)
    )

libraryName=sys.argv[1]
repository=sys.argv[2]
major=int(sys.argv[3])
minor=int(sys.argv[4])
micro=int(sys.argv[5])

from VmsObjectLibrary import VmsObjectLibrary

library=VmsObjectLibrary(libraryName, repository, major, minor, micro)
# library.display()
library.vaxOptionsFile()
library.vaxXferVector()
