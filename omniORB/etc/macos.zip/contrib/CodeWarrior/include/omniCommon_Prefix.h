// -*- Mode: C++; -*-
//
// omniORBCommon_Prefix.h
//
// Copyright (C) 2002-2003 Wolfgang Textor, CoDesCo GmbH.
// Parts Copyright (C) 2002-2003 Dieter Kohl, Quark Deutschland GmbH.
//                               Malge Nishant, Quark India, Inc.
//
// You may redistribute and/or modify this software under the terms of
// the GNU Lesser General Public License.
//
// Description:
//    CodeWarrior common prefix file for all omniORB libraries.
//
// This work is not endorsed or supported by any of the named companies.

/*
 $Log: $
*/


#ifndef	ACCESSOR_CALLS_ARE_FUNCTIONS
	#define ACCESSOR_CALLS_ARE_FUNCTIONS 1
#endif

#if defined(__MWERKS__)
	#if __MACH__
		/*!!
			Make sure, the standard assert file doesn't get loaded!
		*/
		#define FIXINC_BROKEN_ASSERT_STDLIB_CHECK 1
	#endif

	#include <UseDLLPrefix.h>

#endif

#define __powerpc__
#define __macos__
#define __OSVERSION__ 1
#define USE_omniORB_logStream

#define CONFIG_DEFAULT_LOCATION ""
#define CONFIG_ENV ""
//#define NEED_DUMMY_RETURN 1

#include <omniconfig.h>
#undef nil
#define nil nil_t

#pragma export on
