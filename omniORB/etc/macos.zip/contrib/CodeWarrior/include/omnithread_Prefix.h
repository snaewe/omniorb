// -*- Mode: C++; -*-
//
// omnithread_Prefix.h
//
// Copyright (C) 2002-2003 Wolfgang Textor, CoDesCo GmbH.
// Parts Copyright (C) 2002-2003 Dieter Kohl, Quark Deutschland GmbH.
//                               Malge Nishant, Quark India, Inc.
//
// You may redistribute and/or modify this software under the terms of
// the GNU Lesser General Public License.
//
// Description:
//    CodeWarrior prefix file for omnithread 3.0 library.
//
// This work is not endorsed or supported by any of the named companies.

/*
 $Log: $
*/


#define PthreadDraftVersion 10
#define NoNanoSleep

#include "omniCommon_Prefix.h"
