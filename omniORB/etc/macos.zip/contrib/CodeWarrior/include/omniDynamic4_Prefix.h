// -*- Mode: C++; -*-
//
// omniDynamic_Prefix.h
//
// Copyright (C) 2002-2003 Wolfgang Textor, CoDesCo GmbH.
// Parts Copyright (C) 2002-2003 Dieter Kohl, Quark Deutschland GmbH.
//                               Malge Nishant, Quark India, Inc.
//
// You may redistribute and/or modify this software under the terms of
// the GNU Lesser General Public License.
//
// Description:
//    CodeWarrior prefix file for omniDynamic 4.0 library.
//
// This work is not endorsed or supported by any of the named companies.

/*
 $Log: $
*/


#define _OMNIORB_DYNAMIC_LIBRARY

#include "omniCommon_Prefix.h"
