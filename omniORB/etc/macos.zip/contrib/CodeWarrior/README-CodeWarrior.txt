NOTES on CodeWarrior
====================

This is the folder containing Mac OS specific files. Please refer to
README.macos to learn how to use them.


Missing project or library files?
---------------------------------

I was originally planning to create a Carbon and a Mach-O port as
well. But due to time constraints these did not make it into the
current version. Please stay tuned. Of course you are free to
contribute your own port.


Other required libraries
------------------------

You will need GUSI (http://sourceforge.net/projects/gusi/) or any
other POSIX compatibility environment for Mac OS Classic and Carbon
compilations. The project files and this documentation assume that you
have installed GUSI into a folder named GUSI2, which is located in the
same folder as the omniORB distribution folder.


GUSI2 Configuration
-------------------

Please put the contents of the "into GUSI2" folders into the
respective folders within your copy of GUSI. E.g.: the contents of
"into GUSI2:into projects:" should be put into your ":GUSI2:projects:"
folder.

Please import the "GUSIConfig.mcp.xml" file and make it. The library
it produces will be needed to build the shared library versions of
omniORB.


Client Prefix Files
-------------------

To use omniORB, include "omniClient_Prefix.h" before you include
"CORBA.h".  Please be aware of the fact that both the Mac OS headers
and omniORB #define nil to different values. Be sure to #undef (and
possibly re-define) nil before or after you include CORBA headers.


Linking with shared libraries
-----------------------------

If you want to use the shared libraries, please be aware of the
following:

- All omniXXX shared libraries include their more basic siblings,
  i.e. omniORB4.shlb includes omnithread. Just link against what you
  need.

- GUSI is being linked statically into the respective omniXXX shared
  libraries.

- All libraries link against "MSL All.shlb", please be sure to do this
  as well.

- Take care of the link order. You must link against omniXXX before
  you link against MSL, because this is a GUSI requirement. Be sure to
  read the documentation of your POSIX environment to avoid any
  trouble.


Wolfgang Textor, March 2003
